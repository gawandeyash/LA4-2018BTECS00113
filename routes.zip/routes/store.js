var express = require('express');
var router = express.Router();
var mysql=require('mysql');

//connection 
var con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "Gawandeyash7*",
    database:"AWAMAD1"
  });
 // connection complete 
router.get('/',function(req,res,next){
    res.render('inputFile.ejs')
});


//function to insert records
router.post('/', function(req, res, next) {

        console.log(req.body.name)
        console.log(req.body.email)
        console.log(req.body.mob)
        console.log(req.body.book)

        con.connect(function(err) {  
            if (err){
                next(err);
            } 
            console.log("Connected!");  
            var sql = `insert into la4 values(?,?,?,?)`;  
           
            con.query(sql, [req.body.name,req.body.email,req.body.mob,req.body.book], function (err, result) {  
            if (err){
                next(err);
            }
            console.log("records inserted"); 

            
            });  
        });  

        res.render('inputFile.ejs');

  
});

module.exports = router;
