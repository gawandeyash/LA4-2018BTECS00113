var express = require('express');
var router = express.Router();
var mysql=require('mysql');

//connection 
var con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "Gawandeyash7*",
    database:"AWAMAD1"
  });
 // connection complete 


 router.get('/', function(req, res, next) {

    if(!con._connectCalled ){
        con.connect(function(err) {
            if (err){
                next(err);
            };
            console.log("Connected!");
        });

    }

   
       
        
        var sql = `select * from la4`;  
       
        con.query(sql, function (err, result) {  
        if (err){
            next(err);
        }
        console.log(result)
        //res.send(result);
       res.render('displayFile',{records:result});

        });  
});  



  


module.exports = router;
