import React ,{Component} from 'react';
import {BrowserRouter,Switch,Route,Redirect} from 'react-router-dom';
import './App.css';

import Route1 from './component/confirm'
import Home from './component/homepage'


class App extends Component{  
 
  constructor(props){
    super(props);
    
  };

  render(){
           
    return (
     <div>
                  <BrowserRouter>
                
                              <Switch>
                                    {/* <Route exact path="/home" component={()=><Home />} /> */}
                                    <Route path="/homepage">
                                      <Home/>
                                    </Route>
                                    <Route exact path="/route1/:passedParamater" component={()=><Route1 />} />
                                    <Redirect to="/homepage" />     
                              </Switch>
                
                </BrowserRouter>
      </div>
    );



  }
 
}

export default App;
