import React ,{Component,setState} from 'react';
import '../componentCss/home.css';



class Home extends Component{  
 
  constructor(props){
    super(props);

    this.state={
        name:'',
        email:'',
        feed:''
    };
   
    this.onClickRedirectButton=this.onClickRedirectButton.bind(this);
    this.onParamChangeHandler=this.onParamChangeHandler.bind(this);
    this.onParamChangeHandler1=this.onParamChangeHandler1.bind(this);
    this.onParamChangeHandler2=this.onParamChangeHandler2.bind(this);
  };



onClickRedirectButton(event){

    let url="/route1/"+this.state.name;
    window.location.href=url;

}

onParamChangeHandler(event){
  this.setState({name:event.target.value});
}
onParamChangeHandler1(event){
  this.setState({email:event.target.value});
}
onParamChangeHandler2(event){
  this.setState({feed:event.target.value});
}


  render(){
           
    return (
     <div>

         <div id="headerSection">

         <br></br><br></br><br></br><h1>Feedback form</h1><br></br><br></br><br></br>

         </div>
         <hr></hr>

         <div id="redirectSection">
              <label></label><br></br>
             <input type="text" onChange={this.onParamChangeHandler} placeholder="Enter name here"></input><br></br><br></br>
             <input type="email" onChange={this.onParamChangeHandler1} placeholder="Enter your Email-id"></input><br></br><br></br>
             <input type="text" onChange={this.onParamChangeHandler2} placeholder="Your feedback"></input><br></br><br></br>
             <button type="submit" onClick={this.onClickRedirectButton}>Submit</button>

         </div>

        <hr></hr>
        <span >Yash Gawande:2018BTECS00113</span>
     






       
      </div>
    );



  }
 
}

export default Home;
