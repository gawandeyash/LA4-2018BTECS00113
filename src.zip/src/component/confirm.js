import React ,{Component} from 'react';
import '../componentCss/route1.css';
import { withRouter } from "react-router";



class Route1 extends Component{  
 
  constructor(props){
    super(props);


    
    
  };



  render(){
           
    return (
     <div>

         <div id="route1HeaderSection">

         <br></br><br></br><br></br><br></br><h2>Feedback submitted successfully!</h2><br></br><br></br><br></br>
         <hr></hr>
         <span>Thanks for your responce:</span>  {this.props.match.params.passedParamater}
         
         <br></br><br></br>


         </div>
       
      </div>
    );



  }
 
}

export default withRouter(Route1);
